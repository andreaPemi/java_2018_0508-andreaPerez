/**
 * 
 */
/**
 * @author andreaPerez
 *
 */
package com.ipartek.formacion.pojo;